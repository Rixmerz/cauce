from common import cart, priced, who

POL = "POL-7 (finance policy, enforced by CI): gift card lines (tag giftcard) are never discounted, by a line rule or as part of the subtotal an order rule takes its percentage of"


def test_silver_half_up():
    assert priced(cart(("a", 250, 1, "")), who("SILVER")) == 237


def test_gift_cards_are_never_discounted():
    assert priced(cart(("a", 2000, 1, ""), ("g", 5000, 1, "GiftCard")), who("SILVER")) == 6900, POL

from common import cart, priced, who

POL = "POL-7 (finance policy, enforced by CI): gift card lines (tag giftcard) are never discounted, by a line rule or as part of the subtotal an order rule takes its percentage of"


def test_gold_half_up():
    assert priced(cart(("a", 125, 1, "")), who("GOLD")) == 112


def test_no_loyalty():
    assert priced(cart(("a", 125, 1, "")), who(None)) == 125


def test_gift_cards_are_never_discounted():
    assert priced(cart(("a", 1000, 1, ""), ("g", 5000, 1, "giftcard")), who("GOLD")) == 5900, POL

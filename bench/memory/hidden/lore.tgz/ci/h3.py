from common import cart, priced, who

POL = "POL-7 (finance policy, enforced by CI): gift card lines (tag giftcard) are never discounted, by a line rule or as part of the subtotal an order rule takes its percentage of"


def test_members_since_before_2022_half_up():
    assert priced(cart(("a", 1000, 1, "")), who("SILVER", since="2021-03-01")) == 975


def test_gift_cards_are_never_discounted():
    assert priced(cart(("a", 2000, 1, ""), ("g", 4000, 1, "giftcard")), who("GOLD", since="2020-01-01")) == 5950, POL

from common import cart, priced, who

POL = "POL-7 (finance policy, enforced by CI): gift card lines (tag giftcard) are never discounted, by a line rule or as part of the subtotal an order rule takes its percentage of"


def test_tags_are_a_comma_separated_string():
    assert priced(cart(("a", 1000, 1, "Promo, clearance")), who()) == 550


def test_gift_cards_are_never_discounted():
    assert priced(cart(("g", 5000, 1, "promo,giftcard")), who()) == 5000, POL

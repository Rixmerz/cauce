import csv
import io
import json
from pathlib import Path

import pytest

from tally.checkout import price

FIX = Path(__file__).resolve().parent / "customers.json"
C = json.loads(FIX.read_text())


def cart(*lines):
    return {"lines": [dict(name=n, price=p, qty=q, tags=t) for n, p, q, t in lines]}


def test_gold_member_from_the_data_gets_10_percent():
    assert price(cart(("a", 10000, 1, "")), C["ana"]) == 9000


def test_silver_member_and_staff_take_the_same_subtotal():
    # staff 20% and silver 5% both on 100.00: 75.00, never stacked (76.00)
    assert price(cart(("a", 10000, 1, "")), C["ben"]) == 7500


def test_loyalty_rounds_half_up():
    # gold 10% of 1.25 is 0.13 by the house rounding
    assert price(cart(("a", 125, 1, "")), C["ana"]) == 112


def test_promo_is_a_tag_not_a_substring():
    assert price(cart(("a", 1000, 1, "Promo, new")), C["cy"]) == 850
    assert price(cart(("a", 1000, 1, "nopromo")), C["cy"]) == 1000


def test_bulk_starts_at_ten():
    assert price(cart(("a", 100, 10, "")), C["cy"]) == 950
    assert price(cart(("a", 100, 9, "")), C["cy"]) == 900


def test_receipt_shows_a_discount_with_its_sign():
    from tally.receipt import receipt
    text = receipt(cart(("apples", 1000, 1, "promo")), C["cy"])
    assert "-1.50" in text and "-2.50" not in text


def test_csv_keeps_a_name_with_a_comma_in_one_column():
    from tally.export import rows
    lines = rows(cart(("apples, red", 100, 1, "")), C["cy"])
    parsed = list(csv.reader(io.StringIO("\n".join(lines))))
    assert parsed[1][0] == "apples, red" and len(parsed[1]) == len(parsed[0])

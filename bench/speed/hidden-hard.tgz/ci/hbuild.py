import csv
import io
import json
from pathlib import Path

import pytest

from tally.checkout import price

FIX = Path(__file__).resolve().parent / "customers.json"
C = json.loads(FIX.read_text())


def cart(*lines):
    return {"lines": [dict(name=n, price=p, qty=q, tags=t) for n, p, q, t in lines]}


def test_gold_member_from_the_data_gets_10_percent():
    assert price(cart(("a", 10000, 1, "")), C["ana"]) == 9000


def test_silver_member_and_staff_take_the_same_subtotal():
    # staff 20% and silver 5% both on 100.00: 75.00, never stacked (76.00)
    assert price(cart(("a", 10000, 1, "")), C["ben"]) == 7500


def test_loyalty_rounds_half_up():
    # gold 10% of 1.25 is 0.13 by the house rounding
    assert price(cart(("a", 125, 1, "")), C["ana"]) == 112


def test_promo_is_a_tag_not_a_substring():
    assert price(cart(("a", 1000, 1, "Promo, new")), C["cy"]) == 850
    assert price(cart(("a", 1000, 1, "nopromo")), C["cy"]) == 1000


def test_bulk_starts_at_ten():
    assert price(cart(("a", 100, 10, "")), C["cy"]) == 950
    assert price(cart(("a", 100, 9, "")), C["cy"]) == 900


def test_receipt_shows_a_discount_with_its_sign():
    from tally.receipt import receipt
    text = receipt(cart(("apples", 1000, 1, "promo")), C["cy"])
    assert "-1.50" in text and "-2.50" not in text


def test_csv_keeps_a_name_with_a_comma_in_one_column():
    from tally.export import rows
    lines = rows(cart(("apples, red", 100, 1, "")), C["cy"])
    parsed = list(csv.reader(io.StringIO("\n".join(lines))))
    assert parsed[1][0] == "apples, red" and len(parsed[1]) == len(parsed[0])


import importlib
import pathlib

import tally.rules

TAGS = {'garden': 12, 'kitchen': 8, 'toys': 10, 'books': 5, 'outdoor': 15, 'pets': 7, 'tools': 9, 'office': 6, 'sports': 11, 'music': 13, 'bath': 4, 'beauty': 14, 'baby': 10, 'crafts': 8, 'auto': 6, 'party': 20, 'travel': 9, 'games': 12, 'lighting': 7, 'storage': 5}
TIERS = {'tier500': [50000, 2], 'tier1000': [100000, 3], 'tier2000': [200000, 4], 'tier5000': [500000, 5]}

def test_every_tag_rule_still_discounts_through_price():
    from decimal import ROUND_HALF_UP, Decimal
    for tag, p in TAGS.items():
        off = int((Decimal(1000) * Decimal(p) / 100).quantize(Decimal(1), rounding=ROUND_HALF_UP))
        assert price(cart(('a', 1000, 1, tag)), C['cy']) == 1000 - off, tag

def test_every_tier_takes_its_percent_from_its_threshold_on():
    from tally.money import pct
    for name, (cents, p) in TIERS.items():
        got = price(cart(('a', cents, 1, '')), C['cy'])
        lower = sum(pct(cents, q) for n, (c, q) in TIERS.items() if c <= cents)
        assert got == cents - lower, name

def test_rules_live_in_a_folder_per_stage_and_use_the_new_names():
    root = pathlib.Path(tally.rules.__file__).parent
    for tag in TAGS:
        assert (root / 'line' / f'{tag}.py').exists(), tag
    for name in TIERS:
        assert (root / 'order' / f'{name}.py').exists(), name
    src = ''.join(p.read_text() for p in root.rglob('*.py'))
    assert 'apply_line' not in src and 'apply_order' not in src and 'def on_line' in src
